# SIC-Practicals
TY BSc IT Security In Computing Practicals
